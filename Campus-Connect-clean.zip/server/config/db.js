import mongoose from 'mongoose';
import { env } from './env.js';

/**
 * Establish the MongoDB connection. Called once at server startup.
 */
export async function connectDB() {
  if (!env.mongoUri) {
    throw new Error(
      'MONGO_URI is not set. Copy .env.example to server/.env and set MONGO_URI ' +
        '(e.g. mongodb://127.0.0.1:27017/campus_connect or your MongoDB Atlas URI).',
    );
  }

  mongoose.set('strictQuery', true);

  try {
    await mongoose.connect(env.mongoUri, { serverSelectionTimeoutMS: 8000 });
    console.log(`[db] connected to ${mongoose.connection.host}/${mongoose.connection.name}`);
  } catch (error) {
    console.error(`[db] connection failed: ${error.message}`);
    throw error;
  }

  mongoose.connection.on('error', (err) => {
    console.error(`[db] runtime error: ${err.message}`);
  });

  mongoose.connection.on('disconnected', () => {
    console.warn('[db] disconnected');
  });

  return mongoose.connection;
}

/**
 * Disconnect cleanly (used by tests and graceful shutdown).
 */
export async function disconnectDB() {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
  }
}
