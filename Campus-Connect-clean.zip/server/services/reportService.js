import Report from '../models/report.js';
import User from '../models/user.js';
import Post from '../models/post.js';
import Job from '../models/job.js';
import Resource from '../models/resource.js';
import { notFound } from '../utils/ApiError.js';
import { paginationMeta } from '../utils/pagination.js';
import { createNotification } from './notificationService.js';
import { logAudit } from '../utils/audit.js';

const escapeRegExp = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Reports management (spec §16, §20): admins list reports and resolve/dismiss
 * them; resolving can remove the reported content and notify the reporter.
 */

/** List reports (admin) with status/type filters. */
export async function listReports({ filters = {}, page, limit }) {
  const query = {};
  if (filters.status && filters.status !== 'all') query.status = filters.status;
  if (filters.targetType && filters.targetType !== 'all') query.targetType = filters.targetType;
  if (filters.search) query.reason = { $regex: escapeRegExp(filters.search), $options: 'i' };

  const [items, total] = await Promise.all([
    Report.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate({ path: 'reporter', select: 'name email role avatar' })
      .lean(),
    Report.countDocuments(query),
  ]);

  // Enrich with a snippet of the reported content.
  const enriched = await Promise.all(
    items.map(async (report) => {
      let target = null;
      if (report.targetType === 'post') {
        const post = await Post.findById(report.targetId).select('content status author').lean();
        target = post ? { snippet: post.content?.slice(0, 120), status: post.status, author: post.author } : null;
      } else if (report.targetType === 'job') {
        const job = await Job.findById(report.targetId).select('title company status').lean();
        target = job ? { snippet: `${job.title} @ ${job.company}`, status: job.status } : null;
      } else if (report.targetType === 'resource') {
        const resource = await Resource.findById(report.targetId).select('title status').lean();
        target = resource ? { snippet: resource.title, status: resource.status } : null;
      } else if (report.targetType === 'user') {
        const user = await User.findById(report.targetId).select('name role').lean();
        target = user ? { snippet: user.name, status: user.isActive ? 'active' : 'disabled' } : null;
      }
      return { ...report, target };
    }),
  );

  return { items: enriched, meta: paginationMeta(total, page, limit) };
}

/** Resolve/dismiss a report (admin). Optionally removes the content. */
export async function resolveReport({ reportId, status, actorId, removeContent, req }) {
  const report = await Report.findById(reportId);
  if (!report) throw notFound('Report not found', 'REPORT_NOT_FOUND');

  report.status = status;
  report.reviewedBy = actorId;
  report.resolvedAt = new Date();
  await report.save();

  // Optionally remove the reported content (posts only for now — jobs and
  // resources already have their own moderation endpoints).
  let contentRemoved = false;
  if (removeContent && report.targetType === 'post') {
    const post = await Post.findById(report.targetId);
    if (post && post.status === 'published') {
      post.status = 'removed';
      await post.save();
      contentRemoved = true;
      await createNotification({
        recipientId: post.author,
        type: 'post_status',
        title: 'Post removed by moderator',
        body: 'One of your posts was removed after a community report.',
        data: { url: '/community' },
      });
    }
  }

  await logAudit({
    action: 'report_resolve',
    actorId,
    targetType: 'report',
    targetId: reportId,
    details: { status, removeContent, contentRemoved, reportedType: report.targetType },
    req,
  });

  return { report, contentRemoved };
}
