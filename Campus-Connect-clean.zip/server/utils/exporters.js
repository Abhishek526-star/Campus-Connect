import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';

/**
 * Lightweight exporters — CSV (hand-rolled, no unstable deps), XLSX (exceljs),
 * PDF (pdfkit). Used by attendance, reports, receipts, and certificates.
 *
 * `columns` format: [{ key, header, width?, align? }]
 */

const escapeCsv = (value) => {
  const str = value === null || value === undefined ? '' : String(value);
  if (/[",\n\r]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
  return str;
};

export function toCsvBuffer(rows, columns) {
  const header = columns.map((c) => escapeCsv(c.header)).join(',');
  const lines = rows.map((row) =>
    columns.map((c) => escapeCsv(c.render ? c.render(row) : row[c.key])).join(','),
  );
  // Prepend UTF-8 BOM so Excel opens Indian/international characters correctly.
  const csv = '\uFEFF' + [header, ...lines].join('\r\n') + '\r\n';
  return Buffer.from(csv, 'utf8');
}

export async function toXlsxBuffer(rows, columns) {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Data');

  sheet.columns = columns.map((c) => ({
    header: c.header,
    key: c.key,
    width: c.width ?? 20,
  }));
  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8EEFB' } };

  rows.forEach((row) => {
    const out = {};
    columns.forEach((c) => {
      out[c.key] = c.render ? c.render(row) : row[c.key];
    });
    sheet.addRow(out);
  });

  return Buffer.from(await workbook.xlsx.writeBuffer());
}

/**
 * Render a simple table + title into a PDF buffer.
 */
export async function toPdfBuffer({ title, subtitle, rows, columns, landscape = false }) {
  const doc = new PDFDocument({ size: 'A4', layout: landscape ? 'landscape' : 'portrait', margin: 40 });

  const chunks = [];
  doc.on('data', (chunk) => chunks.push(chunk));
  const done = new Promise((resolve) => doc.on('end', resolve));

  const pageWidth = landscape ? 841.89 - 80 : 595.28 - 80;

  doc.fontSize(16).fillColor('#1e3a8a').text(title, { align: 'center' });
  if (subtitle) {
    doc.moveDown(0.3).fontSize(10).fillColor('#64748b').text(subtitle, { align: 'center' });
  }
  doc.moveDown(1.2).fillColor('#0f172a');

  const colWidths = columns.map((c) => c.width ?? Math.floor(pageWidth / columns.length));
  const rowHeight = 20;
  const startX = 40;
  let y = doc.y;

  const drawRow = (cells, isHeader) => {
    const maxY = y + rowHeight;
    cells.forEach((cell, i) => {
      const x = startX + colWidths.slice(0, i).reduce((a, b) => a + b, 0);
      if (isHeader) {
        doc.font('Helvetica-Bold').fontSize(9).fillColor('#1e3a8a');
      } else {
        doc.font('Helvetica').fontSize(8.5).fillColor('#0f172a');
      }
      doc.text(String(cell), x + 4, y + 5, { width: colWidths[i] - 8, height: rowHeight - 8, ellipsis: true });
    });
    if (isHeader) {
      doc.rect(startX, y, pageWidth, rowHeight).fillOpacity(0.08).fill('#2563eb').fillOpacity(1);
    }
    doc.moveTo(startX, maxY).lineTo(startX + pageWidth, maxY).strokeColor('#e2e8f0').stroke();
    y = maxY;
  };

  drawRow(columns.map((c) => c.header), true);
  rows.forEach((row) => {
    if (y > (landscape ? 540 : 760)) {
      doc.addPage();
      y = doc.y;
      drawRow(columns.map((c) => c.header), true);
    }
    drawRow(columns.map((c) => (c.render ? c.render(row) : row[c.key])), false);
  });

  doc.end();
  await done;
  return Buffer.concat(chunks);
}
